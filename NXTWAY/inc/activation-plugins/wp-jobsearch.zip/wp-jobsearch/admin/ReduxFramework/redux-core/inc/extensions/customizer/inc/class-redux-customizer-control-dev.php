<?php
/**
 * Redux Customizer Control Dev Class
 *
 * @class Redux_Customizer_Control_Dev
 * @version 4.0.0
 * @package Redux Framework
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Redux_Customizer_Control_Dev', false ) ) {

	/**
	 * Class Redux_Customizer_Control_Dev
	 */
	class Redux_Customizer_Control_Dev extends WP_Customize_Control {

		/**
		 * Field render.
		 */
		public function render() {

		}

		/**
		 * Label render.
		 */
		public function label() {

		}

		/**
		 * Description render.
		 */
		public function description() {

		}

		/**
		 * Title render.
		 */
		public function title() {

		}
	}
}
